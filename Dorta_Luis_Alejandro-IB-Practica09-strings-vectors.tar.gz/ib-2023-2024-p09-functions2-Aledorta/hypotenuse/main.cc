/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 16 Nov 2023
 * @brief Calcular la hipotenusa
 * @see declarar funciones
 */
#include <iostream>

#include "hypotenuse.h"

int main(int argc, char *argv[]) {
  Usage(argc, argv);
  double primer_cateto = (std::stod(argv[1])), segundo_cateto = (std::stod(argv[2])), resultado;
  resultado = Hypotenuse(primer_cateto, segundo_cateto);
  std::cout << resultado << std::endl;
  return 0;
}