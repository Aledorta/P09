/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 16 Nov 2023
 * @brief Calcular la hipotenusa
 * @see declarar funciones
 */

#include <iostream>
#include <cmath>

/**
 * @brief Muestra el uso correcto del programa en la consola.
 * @details Imprime información sobre el uso correcto del programa, incluyendo el número de argumentos
 * y sus significados.
 * @param[in] argc El número de argumentos de la línea de comandos.
 * @param[in] argv Un array de punteros a caracteres que representan los argumentos de la línea de comandos.
 */
void Usage(int argc, char *argv[]);
/**
 * @brief Calcula la hipotenusa de un triángulo.
 * @details Utiliza el teorema de Pitágoras para calcular la hipotenusa dado dos catetos.
 * @param[in] primer_cateto El primer cateto del triángulo.
 * @param[in] segundo_cateto El segundo cateto del triángulo.
 * @return La longitud de la hipotenusa calculada.
 */
double Hypotenuse(double primer_cateto, double segundo_cateto);