/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 16 Nov 2023
 * @brief Mirar si el número es perfecto
 * @see programa cliente
 */

#include <iostream>

bool is_perfect(int n) {
  int divisor = 1;
  for (int i = 2; i*i <= n; ++i) {
    if ( n % i == 0) {
      divisor += i + n/i;
    } 
  }
  return (divisor == n and n != 0 and n != 1);
}

int main() {
  int numero;
  while (std::cin >> numero) {
    std::cout << is_perfect(numero) << std::endl;
  }
  return 0;
}