/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 16 Nov 2023
 * @brief Escribir caŕacteres en un orden determinado
 * @see programa cliente
 */

#include <iostream>

void print(int s, char c, int n) {
  for (int i=0; i < s; i++) {
    std::cout << " ";
  }
  for (int i=0; i < n; i++) {
    std::cout << c;
  }
  std::cout << std::endl;
  return;
}

int main() {
  int posicion, numero;
  char caracter;
  std::cin >> posicion >> caracter >> numero;
  print(posicion, caracter, numero);
  return 0;
}

