/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 16 Nov 2023
 * @brief Escribir el minimo y el máximo
 * @see programa cliente
 */

#include <iostream>

void min_max(int a, int b, int& mn, int& mx) {
  if (a > b) {
    mn = b;
    mx = a;
  } else {
    mn = a;
    mx = b;
  }
  return;
}

int main() {
  int numero1, numero2, min, max;
  std::cin >> numero1 >> numero2;
  min_max(numero1, numero2, min, max);
  return 0;
}