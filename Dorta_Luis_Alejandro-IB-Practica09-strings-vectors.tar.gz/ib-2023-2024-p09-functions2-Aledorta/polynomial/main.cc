/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 16 Nov 2023
 * @brief Desarrollo de un polinomio
 * @see programa cliente
 */

#include <iostream>

#include "polynomial.h"

int main(int argc, char *argv[]) {
  Usage(argc, argv);
  std::vector<float> coeficientes;
  float valor = (std::stod(argv[argc - 1])), resultado;
  for (int i=1; i < argc - 1; ++i) {
    coeficientes.push_back(std::stod(argv[i]));
  }
  resultado = Polinomio(coeficientes, valor);
  std::cout << resultado << std::endl;
  return 0;
}