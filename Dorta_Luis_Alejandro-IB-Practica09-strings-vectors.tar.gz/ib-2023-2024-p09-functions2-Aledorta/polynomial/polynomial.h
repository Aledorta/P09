/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 16 Nov 2023
 * @brief Desarrollo de un polinomio
 * @see declaración de funciones
 */

#include <iostream>
#include <vector>

/**
 * @brief Muestra el uso correcto del programa en la consola.
 * @details Imprime información sobre el uso correcto del programa, incluyendo el número de argumentos
 * y sus significados.
 * @param[in] argc El número de argumentos de la línea de comandos.
 * @param[in] argv Un array de punteros a caracteres que representan los argumentos de la línea de comandos.
 */
void Usage(int argc, char *argv[]);
/**
 * @brief Calcula el valor de un polinomio para un dado conjunto de coeficientes y un valor de entrada.
 * @details Utiliza la fórmula del polinomio para evaluar su valor en el punto especificado.
 * @param[in] coeficientes Los coeficientes del polinomio, en orden descendente.
 * @param[in] value El valor en el cual se evalúa el polinomio.
 * @return El resultado de evaluar el polinomio en el punto dado.
 */
float Polinomio(std::vector<float> coeficientes, float value);