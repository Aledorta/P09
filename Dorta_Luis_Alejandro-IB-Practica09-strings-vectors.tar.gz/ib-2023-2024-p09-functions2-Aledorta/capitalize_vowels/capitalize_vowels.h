/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 16 Nov 2023
 * @brief Poner en malluscula las vocales
 * @see declaración de funciones
 */

#include <iostream>

/**
 * @brief Muestra el uso correcto del programa en la consola.
 * @details Imprime información sobre el uso correcto del programa, incluyendo el número de argumentos
 * y sus significados.
 * @param[in] argc El número de argumentos de la línea de comandos.
 * @param[in] argv Un array de punteros a caracteres que representan los argumentos de la línea de comandos.
 */
void Usage(int argc, char *argv[]);

/**
 * @brief Capitaliza las vocales en una cadena de caracteres.
 * @details Recibe una cadena de caracteres y capitaliza todas las vocales en ella.
 * @param[in,out] cadena La cadena de caracteres a modificar.
 * @return La cadena modificada con las vocales capitalizadas.
 */
std::string  capitalizeVowels(std::string &cadena);