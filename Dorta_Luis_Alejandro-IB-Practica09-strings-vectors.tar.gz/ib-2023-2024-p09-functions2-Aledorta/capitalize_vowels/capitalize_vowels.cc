/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 16 Nov 2023
 * @brief Poner en malluscula las vocales
 * @see contiene las fucniones de change_case.h
 */

#include "capitalize_vowels.h"

void Usage(int argc, char *argv[]) {
  std::string parameter{argv[1]};
  // Verifica si se proporciona el argumento "--help" para mostrar información de ayuda.
  if (parameter == "--help") {
    const std::string kHelpText = "Cambia las minúsculas por mayúsculas en una cadena y viceversa";
    std::cout << kHelpText << std::endl;
    exit(EXIT_SUCCESS);
  }
  // Verifica si se proporciona la cantidad correcta de argumentos (2 en total, incluido el nombre del programa).
  if (argc < 2) {
    std::cout << argv[0] << ": Falta un número natural como parámetro" << std::endl;
    std::cout << "Pruebe " << argv[0] << " --help para más información" << std::endl;
    exit(EXIT_SUCCESS);
  }
}

std::string capitalizeVowels(std::string &cadena) {
  std::string cadena_modificada;
  for (char &c : cadena) {
    if (std::isalpha(c)) { // Verifica si el carácter es una letra
      if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' ||
        c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U') {
        // Convierte las vocales a mayúsculas
        c = std::toupper(c);
      } else {
        // Convierte las consonantes a minúsculas
        c = std::tolower(c);
      }
    }
    cadena_modificada.push_back(c);
  }
  return cadena_modificada;
}