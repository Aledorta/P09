/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 16 Nov 2023
 * @brief Poner en malluscula las vocales
 * @see programa cliente
 */

#include <iostream>
#include <cctype> // Para la función std::isalpha

#include "capitalize_vowels.h"

int main(int argc, char *argv[]) {
  std::string input = argv[1];
  Usage(argc, argv);
  // Llama a la función para modificar la cadena
  input = capitalizeVowels(input);
  // Muestra la cadena modificada
  std::cout << input << std::endl;
  return 0;
}
