/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 16 Nov 2023
 * @brief Calcular producto escalar
 * @see programa cliente
 */

#include <iostream>
#include <vector>
 
#include "producto_escalar.h"

int main(int argc, char *argv[]) {
  Usage(argc, argv);
  // Convierte los argumentos de la línea de comandos a números de punto flotante y los organiza en dos vectores.
  float numero;
  long resultado;
  std::vector<float> primer_vector, segundo_vector;
  for (int i=1; i < argc; i++) {
    if (i < (argc + 1) / 2) {
      primer_vector.push_back(std::stod(argv[i]));   // Utiliza stod para convertir a float
    } else {
      segundo_vector.push_back(std::stod(argv[i]));  // Utiliza stod para convertir a float
    }
  }
  // Imprime los valores de los vectores organizados en pares.
  for (int i = 0; i < primer_vector.size(); ++i) {
    std::cout << primer_vector[i] << " " << segundo_vector[i] << std::endl;
  }
  resultado = Producto_escalar(primer_vector, segundo_vector);
  std::cout << resultado << std::endl;
  return 0;
}