/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 16 Nov 2023
 * @brief Calcular producto escalar
 * @see contiene las funciones declaradas en hypotenuse.h
 */

#include "producto_escalar.h"

void Usage(int argc, char *argv[]) {
  std::string parameter{argv[1]};
  // Verifica si se proporciona el argumento "--help" para mostrar información de ayuda.
  if (parameter == "--help") {
    const std::string kHelpText = "Cambia las minúsculas por mayúsculas en una cadena y viceversa";
    std::cout << kHelpText << std::endl;
    exit(EXIT_SUCCESS);
  }
  // Verifica si se proporciona la cantidad correcta de argumentos (2 en total, incluido el nombre del programa).
  if (argc < 2) {
    std::cout << argv[0] << ": Falta un número natural como parámetro" << std::endl;
    std::cout << "Pruebe " << argv[0] << " --help para más información" << std::endl;
    exit(EXIT_SUCCESS);
  }

  if (argc % 2 == 0) {
    std::cout << "Los dos vectores tienen que tener el mismo tamaño" << std::endl;
    exit(EXIT_SUCCESS);
  }
}

long Producto_escalar(std::vector<float> primer_vector, std::vector<float> segundo_vector) {
  long resultado = 0;
  for (int i=0; i < primer_vector.size(); ++i) {
    resultado += (primer_vector[i] * segundo_vector[i]);
  }
  return resultado;
}