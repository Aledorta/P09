/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 16 Nov 2023
 * @brief Calcular producto escalar
 * @see declarar funciones
 */

#include <iostream>
#include <vector>

/**
 * @brief Muestra el uso correcto del programa en la consola.
 * @details Imprime información sobre el uso correcto del programa, incluyendo el número de argumentos
 * y sus significados.
 * @param[in] argc El número de argumentos de la línea de comandos.
 * @param[in] argv Un array de punteros a caracteres que representan los argumentos de la línea de comandos.
 */
void Usage(int argc, char *argv[]);
/**
 * @brief Calcula el producto escalar de dos vectores.
 * @details Los vectores deben tener la misma longitud. El producto escalar se calcula sumando el producto de los elementos correspondientes.
 * @param[in] primer_vector El primer vector de números de punto flotante.
 * @param[in] segundo_vector El segundo vector de números de punto flotante.
 * @return El producto escalar de los dos vectores.
 */
long Producto_escalar(std::vector<float> primer_vector, std::vector<float> segundo_vector);