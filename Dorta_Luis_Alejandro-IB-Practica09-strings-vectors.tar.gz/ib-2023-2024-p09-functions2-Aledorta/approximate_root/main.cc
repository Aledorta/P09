/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 16 Nov 2023
 * @brief Aproximar a la raiz
 * @see programa cliente
 */

#include "approximate_root.h"

int main () {
  // Solicita al usuario introducir un número mayor que 0.
  double number {0.f};
  EnterNumber(number);
  MayorThatZero(number);
  // Solicita al usuario introducir valores mayores que 0 para la raíz y el delta
  double root {0.f}, delta {0.f};
  RootDelta(root, delta);
  std::cout << "Root tiene un nuevo valor de: " << Operation(root ,delta ,number) << std::endl;
  return 0;
}