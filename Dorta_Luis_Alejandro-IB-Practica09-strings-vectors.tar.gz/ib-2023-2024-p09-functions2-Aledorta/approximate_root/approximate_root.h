/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 16 Nov 2023
 * @brief Aproximar a la raiz
 * @see declaración de funciones
 */

#pragma once 
#include <iostream>
#include <cmath>
#include <stdexcept>

/**
 * @brief Valor de epsilon utilizado para comparaciones con tolerancia.
 */
const int kEPSILON = 1e-9;

/**
 * @brief Solicita al usuario introducir un número mayor que 0.
 * @param[out] number El número introducido por el usuario.
 */
void EnterNumber(double& number);
/**
 * @brief Verifica si un número es mayor que 0 y lanza una excepción si no lo es.
 * @param[in] number El número a verificar.
 * @throws std::domain_error Si el número es menor o igual a 0.
 */
void MayorThatZero(const double& number);
/**
 * @brief Solicita al usuario introducir valores mayores que 0 para la raíz y el delta.
 * @param[out] root La raíz introducida por el usuario.
 * @param[out] delta El delta introducido por el usuario.
 */
void RootDelta(double& root, double& delta);
/**
 * @brief Realiza operaciones para calcular la raíz de un número de manera aproximada.
 * @param[in,out] root La raíz utilizada en el cálculo.
 * @param[in] delta El delta utilizado en el cálculo.
 * @param[in] number El número para el cual se calcula la raíz.
 * @return La raíz aproximada calculada.
 */
double Operation(double& root,double& delta, const double& number);
